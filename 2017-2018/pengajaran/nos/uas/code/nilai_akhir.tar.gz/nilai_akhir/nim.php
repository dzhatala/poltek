<?php

function getNIM(){

	$MY_NIM="007";  /**GANTI NIM ANDA **/
	
	return $MY_NIM;

}

?>
